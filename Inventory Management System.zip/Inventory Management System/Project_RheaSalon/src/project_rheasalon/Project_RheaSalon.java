
package project_rheasalon;

public class Project_RheaSalon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        frmSignIn Login = new frmSignIn();
        Login.setVisible(true);
        Login.pack();
        Login.setLocationRelativeTo(null);
    }
    
}
